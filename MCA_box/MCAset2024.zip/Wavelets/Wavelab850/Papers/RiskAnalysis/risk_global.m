global Data_______entries Data_______callbacks 
global Signals____entries Signals____callbacks
global Settings___entries Settings___callbacks
global Actions____entries Actions____callbacks
global h_lenmenu h_ntymenu h_nlvmenu h_wavmenu h_thrmenu h_plotmenu
global HC PlotFig plotoption sigchoice
global n signal_name Wav_type noiseamp x_use x_length x_name
global noisetype threshtype x_tmp
global x_fft x_haar x_symm x_coif x_daub x_noise
global fig_hand1 fig_hand2 fig_hand3 fig_hand4
global h_coefmenu h_powermenu h_riskmenu
global h_scalemenu h_valuemenu h_noisemenu h_sizemenu
global allfig fig2 fig3 fig4 upd_ever upd_never fig_list
global Update  fig_update  fig1 back_color printing
    
    
    
 
 
%
%  Part of Wavelab Version 850
%  Built Tue Jan  3 13:20:42 EST 2006
%  This is Copyrighted Material
%  For Copying permissions see COPYING.m
%  Comments? e-mail wavelab@stat.stanford.edu 
