clear global Data_______entries Data_______callbacks 
clear global Signals____entries Signals____callbacks
clear global Settings___entries Settings___callbacks
clear global Actions____entries Actions____callbacks
clear global h_lenmenu h_ntymenu h_nlvmenu h_wavmenu h_thrmenu
clear global h_plotmenu plotoption sigchoice
clear global HC PlotFig 
clear global n signal_name Wav_type noiseamp x_use x_length x_name
clear global noisetype threshtype x_tmp
clear global x_fft x_haar x_symm x_coif x_daub x_noise
clear global fig_hand1 fig_hand2 fig_hand3 fig_hand4
clear global h_coefmenu h_powermenu h_riskmenu
clear global h_scalemenu h_valuemenu h_noisemenu h_sizemenu
clear global allfig fig2 fig3 fig4 fig1 upd_ever upd_never fig_list
clear global Update fig_update back_color printing
    
    
    
 
 
%
%  Part of Wavelab Version 850
%  Built Tue Jan  3 13:20:42 EST 2006
%  This is Copyrighted Material
%  For Copying permissions see COPYING.m
%  Comments? e-mail wavelab@stat.stanford.edu 
