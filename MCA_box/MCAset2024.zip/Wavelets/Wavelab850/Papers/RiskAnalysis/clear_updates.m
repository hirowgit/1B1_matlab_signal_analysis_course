global allfig fig1 fig2 fig3 fig4 upd_never upd_ever
global fig_list fig_update
set(fig1,'value',0);
set(fig2,'value',0);
set(fig3,'value',0);
set(fig4,'value',0);
set(allfig,'value',0);
set(upd_never,'value',0);
set(upd_ever,'value',0);
fig_list = [0 0 0 0];
    
    
 
 
%
%  Part of Wavelab Version 850
%  Built Tue Jan  3 13:20:42 EST 2006
%  This is Copyrighted Material
%  For Copying permissions see COPYING.m
%  Comments? e-mail wavelab@stat.stanford.edu 
